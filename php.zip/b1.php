    <div class="container">
        <div class="top-section">
            <img src="./logo/logo.jpg" alt="Logo" class="logo">
            <a href="https://www.bing.com" target="_blank">
                <img src="./logo/exit.png" alt="Exit" class="exit-icon">
            </a>
        </div>
        <div class="divider"></div>
        <div class="middle-section">
            <div class="divider"></div>
            <div class="right-section">
                <div class="left-subsection">



