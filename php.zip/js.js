    document.addEventListener('DOMContentLoaded', function() {
        new MediaElementPlayer('#video', {
            pluginPath: 'https://cdnjs.cloudflare.com/ajax/libs/mediaelement/4.2.16/',
            success: function(media) {
                // 显示自定义控件
                media.addEventListener('loadedmetadata', function() {
                    document.querySelector('.mejs__controls').style.display = 'flex';
                });
            }
        });

        // 按钮交互逻辑
        const buttonA = document.getElementById('buttonA');
        const buttonB = document.getElementById('buttonB');
        const buttonC = document.getElementById('buttonC');
        const homepageIcon = document.getElementById('homepageIcon');
        const searchICON = document.getElementById('searchICON');
        const gengduoICON = document.getElementById('gengduoICON');

        buttonA.addEventListener('click', function() {
            buttonA.classList.add('active');
            buttonB.classList.remove('active');
            buttonC.classList.remove('active');
            homepageIcon.src = './logo/homepage0.png'; // 按下后的图标
            searchICON.src = './logo/search0.png';
            gengduoICON.src = './logo/gengduo0.png';
        });

        buttonB.addEventListener('click', function() {
            buttonB.classList.add('active');
            buttonA.classList.remove('active');
            buttonC.classList.remove('active');
            homepageIcon.src = './logo/homepage1.png'; // 恢复原图标
            searchICON.src = './logo/search1.png';
            gengduoICON.src = './logo/gengduo0.png';
        });

        buttonC.addEventListener('click', function() {
            buttonC.classList.add('active');
            buttonA.classList.remove('active');
            buttonB.classList.remove('active');
            homepageIcon.src = './logo/homepage1.png'; // 恢复原图标
            searchICON.src = './logo/search0.png';
            gengduoICON.src = './logo/gengduo1.png';
        });

        // 点赞按钮逻辑
        const dianzanButton = document.getElementById('dianzanButton');
        const dianzanIcon = document.getElementById('dianzanIcon');
        let isDianzan = false;

        dianzanButton.addEventListener('click', function() {
            isDianzan = !isDianzan;
            dianzanIcon.src = isDianzan ? './logo/ic/dianzan1.png' : './logo/ic/dianzan0.png';
        });

        // 收藏按钮逻辑
        const shoucangButton = document.getElementById('shoucangButton');
        const shoucangIcon = document.getElementById('shoucangIcon');
        let isShoucang = false;

        shoucangButton.addEventListener('click', function() {
            isShoucang = !isShoucang;
            shoucangIcon.src = isShoucang ? './logo/ic/shoucang1.png' : './logo/ic/shoucang0.png';

            if (isShoucang) {
                // 浏览器收藏逻辑
                alert('已添加到收藏夹');
            } else {
                alert('已取消收藏');
            }
        });

        // 转发按钮逻辑
        const zhuanfaButton = document.getElementById('zhuanfaButton');
        const zhuanfaIcon = document.getElementById('zhuanfaIcon');

        zhuanfaButton.addEventListener('click', function() {
            zhuanfaIcon.src = './logo/ic/zhuanfa1.png'; // 按下后的图标

            // 复制当前页面 URL 到剪贴板
            navigator.clipboard.writeText(window.location.href).then(function() {
                alert('当前页面 URL 已复制到剪贴板');
            }, function(err) {
                console.error('复制失败!', err);
            });
        });
    });
    



