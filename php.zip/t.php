<?php
$base = 't1';
$m4s_path = '/var/www/html/vid/'.$base.'/'.$base.'.m4s';
include 'head.php';
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $base ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mediaelement/4.2.16/mediaelementplayer.min.css">
    <link rel="stylesheet" href="mmt.css"></style>
    <script src="https://dis.ikgy.top/discuss.js"></script>
</head>
<body>
<?php include 'b1.php';?>
                    <div class="box">
                        <?php if(!empty($error)): ?>
                            <div class="error-box">
                                <h2>播放错误 (<?= strtoupper($error) ?>)</h2>
                                <button onclick="location.reload()">重试</button>
                                <p>技术支持：arona@ikgy.top</p>
                            </div>
                        <?php else: ?>
                            <video id="video" controls playsinline>
                                <source src="/<?= $base ?>/<?= $base ?>.m4s" 
                                    type="video/mp4; codecs=avc1.64001F, mp4a.40.2">
                            </video>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="divider"></div> <!-- 中间分隔线 -->
                <div class="right-subsection">                    
                <div class="rounded-box">
                <div id="Discuss-Comments"></div>  
                    </div>
                </div>
            </div>
        </div>
        <div class="divider"></div>
        <div class="bottom-section">
            <p>&copy; Powered By <a href="https://www.ikgy.top" style="color:#ffffff;">ikgy.top</a>      THEME:&copy; NEXON & YOSTART > Blue Archive-Momotalk</p> <!-- 添加版权信息 -->
        </div>
    </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/mediaelement/4.2.16/mediaelement-and-player.min.js"></script>
<script src="js.js"></script>
<script>
    // 初始化
    discuss.init({
      el: '#Discuss-Comments',
      serverURLs: 'https://dis.ikgy.top/'

    })
  </script>
</body>
</html>




