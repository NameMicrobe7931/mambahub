#!/bin/bash

# 视频处理自动化脚本（集成评论区版本）
# 版本：3.0
# 最后更新：2023-12-05

set -eo pipefail
shopt -s nullglob

ROOT_VID_DIR="/var/www/html/vid"
WEB_PLAYER_DIR="$ROOT_VID_DIR/vidp"
LOG_FILE="/var/log/video-processor.log"

FFMPEG_OPTIONS=(
    -c:v libx264
    -profile:v high
    -level 4.1
    -pix_fmt yuv420p
    -crf 22
    -preset faster
    -movflags +faststart
    -c:a aac
    -b:a 128k
    -ar 44100
    -f mp4
)

init_directories() {
    mkdir -p "$ROOT_VID_DIR" "$WEB_PLAYER_DIR" || {
        log_error "目录创建失败"
        exit 1
    }
}

log_info() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] INFO: $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1" >&2 | tee -a "$LOG_FILE"
    exit 1
}

generate_player() {
    local basename="$1"
    local php_file="$WEB_PLAYER_DIR/$basename.php"
    
    cat > "$php_file" <<-EOF
<?php
require __DIR__.'/../../db.php';
\$base = '$basename';
\$m4s_path = '$ROOT_VID_DIR/'.\$base.'/'.\$base.'.m4s';

// 文件验证
clearstatcache();
if (!file_exists(__FILE__)) {
    \$error = 'urlerr';
} elseif (!is_readable(\$m4s_path)) {
    header("HTTP/1.1 403 Forbidden");
    \$error = 'viderr';
} else {
    \$last_modified = filemtime(\$m4s_path);
    header("Last-Modified: " . gmdate("D, d M Y H:i:s", \$last_modified) . " GMT");
    header("Cache-Control: public, max-age=604800");
}
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= \$base ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mediaelement/4.2.16/mediaelementplayer.min.css">
    <link rel="stylesheet" href="/vid/mmc.css">
</head>
<body>
    <?php include __DIR__.'/../../header.php'; ?>
    <div class="container">
        <!-- 原有播放器结构 -->
        <div class="right-subsection">
            <div class="rounded-box">
                <?php include __DIR__.'/../../comments.php?video='.\$base; ?>
            </div>
        </div>
    </div>
    <script src="/vid/mmc.js"></script>
</body>
</html>
EOF
}

main() {
    exec 3>&1 4>&2
    exec > >(tee -a "$LOG_FILE") 2>&1

    log_info "===== 处理开始 ====="
    init_directories

    for mp4file in "$ROOT_VID_DIR"/*.mp4; do
        [ -f "$mp4file" ] || continue
        process_video "$mp4file"
    done

    chmod -R 755 "$ROOT_VID_DIR"
    log_info "===== 处理完成 ====="
}

main "$@"